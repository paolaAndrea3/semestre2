/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empresa;

import javax.swing.JOptionPane;

/**
 *
 * @author Desarrollo
 */
public class Empresa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double produc;
        double serv;
        double emple;
        double mate;
        produc = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la cuenta producto"));
        serv = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la cuenta servicios"));
        emple = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la cuenta empleado"));
        mate = Double.parseDouble(JOptionPane.showInputDialog("Ingresa la cuenta materia prima"));
       
        Estado_Financiero estado = new Estado_Financiero(produc, serv, emple, mate);
        estado.CalcularEstado();
    }
    
}
