/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empresa;

import javax.swing.JOptionPane;

/**
 *
 * @author Desarrollo
 */
public class Estado_Financiero {
    private double producto;
    private double servicios;
    private double empleados;
    private double materiap;
    
    public Estado_Financiero(double prod, double ser, double emp, double mat){
        this.producto = prod;
        this.servicios = ser;
        this.empleados = emp;
        this.materiap = mat;
    }
    
    public double getProducto(){
        return producto;
    }
    public double getServicios(){
        return servicios;
    }
    public double getEmpleados(){
        return empleados;
    }
    public double getMateriap(){
        return materiap;
    }
    
    public void setProducto(double prod){
        this.producto = prod;
    }
    public void setServicios(double ser){
        this.servicios = ser;
    }
    public void setEmpleados(double emp){
        this.empleados = emp;
    }
    public void setMateriap(double mat){
        this.materiap = mat;
    }
    
    public void CalcularEstado(){
        double resultado;
        
        double asesorias = this.servicios * 0.10;
        double ingresos = (this.producto + this.servicios + asesorias);
        
        double consultoria = this.servicios*0.05;
        double impuesto = (this.empleados + this.materiap + consultoria)*0.19;
        double egresos = this.empleados + this.materiap + consultoria + impuesto;
        
        resultado = ingresos - egresos;
        JOptionPane.showMessageDialog(null, "El estado financiero actual es "+resultado);
    }

}
