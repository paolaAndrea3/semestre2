/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package escuela;

import javax.swing.JOptionPane;

/**
 *
 * @author Desarrollo
 */
public class Escuela {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        double n1;
        double n2;
        double n3;
        n1 = Double.parseDouble(JOptionPane.showInputDialog("Ingresa nota 1"));
        n2 = Double.parseDouble(JOptionPane.showInputDialog("Ingresa nota 2"));
        n3 = Double.parseDouble(JOptionPane.showInputDialog("Ingresa nota 3"));
       
        Notas Calificaciones = new Notas(n1, n2, n3);
        Calificaciones.Calcular();
        
    }
    
}
