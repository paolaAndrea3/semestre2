/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package escuela;

import javax.swing.JOptionPane;

/**
 *
 * @author Desarrollo
 */
public class Notas {


    public double  nota1;
    public double  nota2;
    public double  nota3;
    
    public Notas(double n1,double n2, double n3){
        this.nota1 = n1;
        this.nota2 = n2;
        this.nota3 = n3;
    }
    
    public double getNota1(){
        return nota1;
    }
    
    public double getNota2(){
        return nota2;
    }
    
    public double getNota3(){
        return nota3;
    }
    
    public void setNota1(double n1){
        this.nota1 = n1;
    }
    
    public void setNota2(double n2){
        this.nota2 = n2;
    }
    
    public void setNota3(double n3){
        this.nota3 = n3;
    }
    
    public void Calcular(){
        double resultado;
        resultado = (this.nota1 + this.nota2 + this.nota3)/3;
        JOptionPane.showMessageDialog(null, "La nota del primer periodo es de "+resultado);
    }
    
}
